package expressivo;

/**
 * Represents a literal numeric value in an expression.
 * Immutable and recursive.
 */
public class Literal implements Expression {
    private final double value;

    // Rep invariant: value >= 0
    // Abstraction function: represents a numeric literal in an expression
    // Safety from rep exposure: value is private and final

    public Literal(double value) {
        this.value = value;
        checkRep();
    }

    private void checkRep() {
        assert value >= 0;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Literal)) return false;
        Literal that = (Literal) obj;
        return Double.compare(this.value, that.value) == 0;
    }

    @Override
    public int hashCode() {
        return Double.hashCode(value);
    }
}
