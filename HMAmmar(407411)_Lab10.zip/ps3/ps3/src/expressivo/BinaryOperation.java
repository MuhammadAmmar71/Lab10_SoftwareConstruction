package expressivo;

/**
 * Represents a binary operation (+ or *) in an expression.
 * Immutable and recursive.
 */
public class BinaryOperation implements Expression {
    private final String operator;
    private final Expression left;
    private final Expression right;

    // Rep invariant: operator is "+" or "*"
    // Abstraction function: represents a binary operation
    // Safety from rep exposure: fields are private and final

    public BinaryOperation(String operator, Expression left, Expression right) {
        this.operator = operator;
        this.left = left;
        this.right = right;
        checkRep();
    }

    private void checkRep() {
        assert operator.equals("+") || operator.equals("*");
        assert left != null && right != null;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " " + operator + " " + right.toString() + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof BinaryOperation)) return false;
        BinaryOperation that = (BinaryOperation) obj;
        return this.operator.equals(that.operator)
            && this.left.equals(that.left)
            && this.right.equals(that.right);
    }

    @Override
    public int hashCode() {
        return operator.hashCode() + 31 * left.hashCode() + 31 * right.hashCode();
    }
}
