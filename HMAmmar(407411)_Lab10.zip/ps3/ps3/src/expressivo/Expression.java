package expressivo;

/**
 * Expression is an immutable abstract data type representing a mathematical expression
 * involving:
 * - Variables (strings of letters, case-sensitive)
 * - Numbers (nonnegative integers and floating-point numbers)
 * - Binary operators + and *
 *
 * This interface specifies methods for parsing, equality, string representation,
 * and hashing.
 */
public interface Expression {
    
    /**
     * Parse an expression.
     * @param input string representation of the expression
     * @return expression AST for the input
     * @throws IllegalArgumentException if the input expression is invalid
     */
    public static Expression parse(String input) {
        // Placeholder: Actual implementation goes here.
        throw new RuntimeException("unimplemented");
    }

    /**
     * @return a parsable representation of this expression, such that
     * for all e:Expression, e.equals(Expression.parse(e.toString())).
     */
    @Override 
    public String toString();

    /**
     * @param thatObject any object
     * @return true if and only if this and thatObject are structurally-equal Expressions
     */
    @Override
    public boolean equals(Object thatObject);

    /**
     * @return hash code value consistent with the equals() definition
     */
    @Override
    public int hashCode();
}
