package expressivo;

/**
 * Represents a variable in an expression.
 * Immutable and recursive.
 */
public class Variable implements Expression {
    private final String name;

    // Rep invariant: name is a nonempty string of letters
    // Abstraction function: represents a variable in an expression
    // Safety from rep exposure: name is private and final

    public Variable(String name) {
        this.name = name;
        checkRep();
    }

    private void checkRep() {
        assert name.matches("[a-zA-Z]+");
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Variable)) return false;
        Variable that = (Variable) obj;
        return this.name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }
}
