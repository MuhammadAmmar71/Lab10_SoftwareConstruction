package expressivo;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExpressionTest {

    @Test
    public void testLiteralToString() {
        Expression literal = new Literal(3.0);
        assertEquals("3.0", literal.toString());
    }

    @Test
    public void testVariableToString() {
        Expression variable = new Variable("x");
        assertEquals("x", variable.toString());
    }

    @Test
    public void testBinaryOperationToString() {
        Expression expr = new BinaryOperation("+", new Variable("x"), new Literal(3));
        assertEquals("(x + 3.0)", expr.toString());
    }

    @Test
    public void testEqualsAndHashCode() {
        Expression expr1 = new BinaryOperation("+", new Literal(3), new Variable("x"));
        Expression expr2 = new BinaryOperation("+", new Literal(3), new Variable("x"));
        assertEquals(expr1, expr2);
        assertEquals(expr1.hashCode(), expr2.hashCode());
    }
}
